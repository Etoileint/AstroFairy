# 当前开发状态

核对日期：2026-11-08。本文件是新接手者的导航；Issue 的实时状态以 GitHub 为准，
版本事实以标签、发布说明及其对应源码为准。它不代替协议或设计规范。

## 从这里接手

1. 阅读 [AGENTS.md](AGENTS.md) 和 [CONTRIBUTING.md](CONTRIBUTING.md)。
2. 按 README 的开发命令准备环境，启用提交钩子，执行 `dev/check.py`。
3. 从 [AstroFairy Issues](https://github.com/Etoileint/AstroFairy/issues) 选择已授权的任务，
   先核实报告与影响域，再设计、实现和验证。下面的历史批次不是自动重开的任务单。
4. 接手验收取证时，先读[证据获取与复验](docs/development/evidence.md)。
   使用维护者外部开发组织时，按[组织接入规则](CONTRIBUTING.md#external-development-organization)加载原件。

## 已发布基准

- [0.1.0a2 Alpha](https://github.com/Etoileint/AstroFairy/releases/tag/v0.1.0a2)，2026-11-03 发布。
- 源提交：`1574ce89dd2e29e9a3b0be5997302b32b0bfe335`；技能目录和调用名为 `fairy`。
- 0.1.0a2 的发布事实为协议及存储格式10、文档归档格式1；当前开发工作树已推进到协议11、
  阶段包2、回执投影2、存储10、归档1。开发期没有旧库迁移或接口兼容负担。
- [本版双语说明](docs/releases/v0.1.0a2.md)、[项目逻辑讲解](docs/guides/understanding-astrofairy.md)。
- 发布时主分支及标签 CI 通过；附件下载、校验和、固定版本安装及新依赖环境验证通过。
  [主分支 CI](https://github.com/Etoileint/AstroFairy/actions/runs/41628414958)与
  [标签 CI](https://github.com/Etoileint/AstroFairy/actions/runs/41628640927)是公开记录。

## 当前收到的问题

以下四条公开反馈**保持开放**。W1–W5实现、W6首轮独立验收、两轮定向返工与两次独立复验已执行；
执行者已完成第三次定向返工并自检，待原会话再次独立复验。维护者最终接受、提交/推送/发布均未发生。
Issue 中的复现步骤和建议是待核实材料，不自动成为实现要求。

| 入口 | 报告范围 | 接续要求 |
|---|---|---|
| [#1](https://github.com/Etoileint/AstroFairy/issues/1) | 已确认宿主marker求值导致Windows条件依赖遗漏 | 原生Windows安装留待修复验收 |
| [#2](https://github.com/Etoileint/AstroFairy/issues/2) | 已复现空活跃库显式refresh跳过模型准备；doctor只有依赖元数据检查 | 显式准备、真实消费清单、分层就绪契约须统一 |
| [#3](https://github.com/Etoileint/AstroFairy/issues/3) | 上游源码与Windows路径表示模拟确认适配边界错误 | 原生Windows路径/交付仍未执行 |
| [#4](https://github.com/Etoileint/AstroFairy/issues/4) | Linux已复现close/晚到反馈导出失败仍delivered，重开运行时仍在 | 关闭事实、稳定收据、导出观测与安全恢复须分责 |

#3 与 #4 分别核实，后者已确认不限于Windows。现有源码和试验限界见
[专项供料](docs/repairs/2026-11-platform-readiness-delivery/supply.md)。
[候选方案](docs/repairs/2026-11-platform-readiness-delivery/README.md)覆盖四反馈和独立检查发现的相关根因：
receipt依赖当前checker registry、交付祖先redirect、模型配置漏校验及显式验证复用旧缓存。
实施执行者已按方案完成 W1–W5 和自检（依赖锁统一、检索准备与分层诊断、BagIt 路径边界、
交付与恢复、分发与说明同步）。证据回交目录为 `issue-repair-implementation/2026-11-08/return/`
（位于本机忽略的 `.evaluation/`，普通 clone 不含；转交须附清单与哈希）。
2026-11-08维护者指示由另一agent按方案实施W1–W5，原会话承担W6独立验收；执行分派见专项计划。
W6首轮确认6项规范问题、4项新增实现缺陷及1项范围内既有符合性遗漏，见
[验收结论](docs/repairs/2026-11-platform-readiness-delivery/acceptance-2026-11-08/README.md)及
[定向返工](docs/repairs/2026-11-platform-readiness-delivery/acceptance-2026-11-08/rework.md)。
维护者已指示交原实施agent按清单返工。执行者已回交STD01–STD06、SPEC01–SPEC04、GAP01与T29/T35自检，
见[返工记录](docs/audit/changes/2026-11-08_platform-readiness-rework.md)。再次独立复验见
[新结论](docs/repairs/2026-11-platform-readiness-delivery/acceptance-recheck-2026-11-08/README.md)和
[再次返工要求](docs/repairs/2026-11-platform-readiness-delivery/acceptance-recheck-2026-11-08/rework.md)：
STD05/STD06、SPEC02/SPEC03/GAP01/T35通过；工具身份/来源/消费者、三profile交叉检查、不可读安全树、
修复进度及数据库提交确定性仍有缺口，另确认整段precommit默认false的新增回归。
执行者随后完成第二次定向返工：STD01–STD04、SPEC01、SPEC04、T29＋REG02按机制边界修复并自检，
见[第二次返工记录](docs/audit/changes/2026-11-08_platform-readiness-rework2.md)。
本轮回交自检为241运行测试（默认1skip）、40开发测试、验收方两轴探针重跑、分发 wheel/sdist/ZIP 全新安装
及真实缓存字节验证通过；不能抵销未执行的原生Windows、Linux x86_64 CI、macOS、冷模型下载/推理、
junction/reparse、跨进程缓存锁、skills CLI 矩阵与真实 host 交互义务。真实E5基于既有缓存的推理烟测
在首轮验收中通过，本轮未重跑推理。第二次回交证据根为
`issue-repair-implementation/rework2-2026-11-08/`（同样位于忽略目录）。
第二次返工的[独立复验](docs/repairs/2026-11-platform-readiness-delivery/acceptance-recheck2-2026-11-08/README.md)
已完成：STD02–04与SPEC01闭合，STD05/06、SPEC02/03、GAP01/T35保持；原REG02错误false修复。
剩余工具执行体摘要、原生事务异常确定性、invoked提交未知时的call/调查身份及交付返回前进度封装4类P2，
见[定向返工](docs/repairs/2026-11-platform-readiness-delivery/acceptance-recheck2-2026-11-08/rework.md)。
主验收者独立完整检查241运行（默认1skip）＋40开发及真实E5缓存推理通过；独立两轴定向检查与分发源码核对通过。
执行者随后完成第三次定向返工：STD01执行体摘要、F1交付进度边界（含锁释放）、F2事务体原生异常确定性、
F3 invoked提交未知时的call与调查动作已修复并自检，见
[第三次返工记录](docs/audit/changes/2026-11-08_platform-readiness-rework3.md)。
本轮回交自检为249运行测试（默认1skip）、42开发测试、原验收探针重跑、分发 wheel/sdist/ZIP 全新安装
及真实缓存字节验证通过；第三次回交证据根为 `issue-repair-implementation/rework3-2026-11-08/`。
以上不能抵销具体失败反例或未执行的原生平台/冷下载/宿主义务。本轮未最终接受，不发布修复声明。
维护者接受和提交发布尚未发生。该授权不包含外部消息、提交、推送、发布、关闭Issue或修改兄弟仓库。

## 已完成批次与仍待观察的效果

初版技术修复及后续整体优化已有各自的验收记录。
[2026-11-03 最终技术验收](docs/optimization/2026-11-acceptance/final-2026-11-03/README.md)
关闭了当时原10项发现、流式校验回归和收尾发现。发布检查收集195项运行测试
（194通过，默认跳过的真实模型测试另行通过），20项开发测试通过。
这是该版本和试验范围下的历史结论，不覆盖发布后的新报告。

真实成员易用性、宿主遵循率、广泛跨平台和原生插件生命周期、冷模型下载环境及长期团队收益，
继续按各项记录保留限界。它们不因发布而自动通过，也不要求无期限等待才能开展正常开发。

历史入口：[早期复核](docs/reviews/README.md)、[早期修复与工作范围](docs/repairs/README.md)、
[整体优化](docs/optimization/README.md)、[设计与变更记录](docs/audit/INDEX.md)。
旧交接中的未提交工作树、旧目录、旧格式号、旧任务状态和当时授权，只解释其冻结时点。
当前开发使用本入口、现行指南、真实源码与本次任务授权。

## 维护此入口

发布新版本、确定任务优先级或改变验证范围时，更新本文件的日期及链接；历史报告保留原基准。
新增可复用设计决定进入 ADR，任务执行和审查事实进入项目记录。产品经验仍进入外置资产库，
不持续追加到 AGENTS.md 或 CLAUDE.md。
