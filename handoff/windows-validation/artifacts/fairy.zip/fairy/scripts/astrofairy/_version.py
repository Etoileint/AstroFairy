from __future__ import annotations

__version__ = "0.1.0a2"
